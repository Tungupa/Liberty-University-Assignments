#include "BufferBlockADT.h"
#include <cstring>

class BufferBlock : public BufferblockADT 
{
    private:
        int blockID;
        char* block;
        int blockSize;

    public:
        BufferBlock() : blockID(-1), block(nullptr), blockSize(4096) 
        {
            block = new char[blockSize];
            memset(block, 0, blockSize);
        }

        ~BufferBlock() 
        {
            delete[] block;
        }

        void getData(int pos, int sz, char* data) override 
        {
            if (pos + sz > blockSize) sz = blockSize - pos;
            memcpy(data, block + pos, sz);
        }

        void setID(int id) override 
        {
            blockID = id;
        }

        int getID() const override 
        {
            return blockID;
        }

        int getBlocksize() const override 
        {
            return blockSize;
        }

        char* getBlock() const override 
        {
            return block;
        }

        void setBlock(char* blk) override 
        {
            memcpy(block, blk, blockSize);
        }
};
